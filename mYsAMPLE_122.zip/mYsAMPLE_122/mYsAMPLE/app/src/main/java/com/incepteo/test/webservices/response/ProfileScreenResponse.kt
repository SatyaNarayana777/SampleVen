package com.incepteo.test.webservices.response

import com.google.gson.annotations.SerializedName

/*
* "IW_fCRN" = 4499;
    "IW_fDateOfBirth" = "1974-02-07";
    "IW_fEmergencyContact1" = 123131;
    "IW_fEmergencyContact1Phone" = "12 312 3";
    "IW_fEmergencyContact2" = 23123;
    "IW_fEmergencyContact2Phone" = "12 312 313";
    "IW_fFullname" = "Mrs Alexandra Washington ";
    "IW_fGender" = Female;
    "IW_fHomeAddress" = "8595 Central Avenue";
    "IW_fHomeCity" = Brisbane;
    "IW_fHomeCountry" = 436052660;
    "IW_fHomePostCode" = 4000;
    "IW_fHomeStateProvince" = 436052952;
    "IW_fPreferredMailingAddress" = "8595 Central Avenue<br/>Brisbane QLD 4000<br/>Australia";
    "IW_fPrefix" = Mrs;
    firstName = Alexandra;
    id = 436057934;
    lastName = Washington;
    middleName = E;
    name = "Alexandra Washington";
    objName = "IW_oPerson";
* */

data class ProfileScreenResponse(@SerializedName("IW_fCRN") val iW_fCRN : String,
                                 @SerializedName("IW_fDateOfBirth") val iW_fDateOfBirth : String,
                                 @SerializedName("IW_fEmergencyContact1") val iW_fEmergencyContact1 : String,
                                 @SerializedName("IW_fEmergencyContact1Phone") val iW_fEmergencyContact1Phone : String,
                                 @SerializedName("IW_fEmergencyContact2") val iW_fEmergencyContact2 : String,
                                 @SerializedName("IW_fEmergencyContact2Phone") val iW_fEmergencyContact2Phone : String,
                                 @SerializedName("IW_fFullname") val iW_fFullname : String,
                                 @SerializedName("IW_fGender") val iW_fGender : String,
                                 @SerializedName("IW_fHomeAddress") val iW_fHomeAddress : String,
                                 @SerializedName("IW_fHomeCity") val iW_fHomeCity : String,
                                 @SerializedName("IW_fHomeCountry") val iW_fHomeCountry : String,
                                 @SerializedName("IW_fHomePostCode") val iW_fHomePostCode : String,
                                 @SerializedName("IW_fHomeStateProvince") val iW_fHomeStateProvince : String,
                                 @SerializedName("IW_fPreferredMailingAddress") val iW_fPreferredMailingAddress : String,
                                 @SerializedName("IW_fPhotographRawURL") val iW_fPhotographRawURL : String,
                                 @SerializedName("IW_fPrefix") val iW_fPrefix : String,
                                 @SerializedName("firstName") val firstName : String,
                                 @SerializedName("id") val id : String,
                                 @SerializedName("lastName") val lastName : String,
                                 @SerializedName("middleName") val middleName : String,
                                 @SerializedName("name") val name : String,
                                 @SerializedName("objName") val objName : String)

