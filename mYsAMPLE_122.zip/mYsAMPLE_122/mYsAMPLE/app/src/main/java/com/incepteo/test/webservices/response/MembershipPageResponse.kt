package com.incepteo.test.webservices.response

import com.google.gson.annotations.SerializedName

data class MembershipPageResponse(@SerializedName("IW_fActivateOnlineRenewal") val iW_fActivateOnlineRenewal : String,
                                  @SerializedName("IW_fEndDate")  val iW_fEndDate : String,
                                  @SerializedName("IW_fMemberID")  val iW_fMemberID : String,
                                  @SerializedName("IW_fMemberName")  val iW_fMemberName : String,
                                  @SerializedName("IW_fMemberTypeName")  val iW_fMemberTypeName : String,
                                  @SerializedName("IW_fMembershipGroupName")  val iW_fMembershipGroupName : String,
                                  @SerializedName("IW_fMembershipProductCode")  val iW_fMembershipProductCode : String,
                                  @SerializedName("IW_fOrganisation")  val iW_fOrganisation : String,
                                  @SerializedName("objName")  val objName : String,
                                  @SerializedName("id")  val id : String)
