package com.incepteo.test.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.incepteo.test.R
import com.incepteo.test.model.DashboardActivityModel
import com.incepteo.test.webservices.response.MembershipPageResponse

class MembershipAdapter constructor(private val membershipPageResponse : List<MembershipPageResponse>) : RecyclerView.Adapter<MembershipAdapter.ViewHolder>() {

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val view: View = LayoutInflater.from(p0.context).inflate(R.layout.row_item_membership, p0, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return membershipPageResponse.size
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        p0.updateUi(p1)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val tvMemName : TextView = itemView.findViewById(R.id.tvMemName)
        val tvMemCat : TextView = itemView.findViewById(R.id.tvMemCat)
        val tvMemExpDate : TextView = itemView.findViewById(R.id.tvMemExpDate)
        val tvMemId : TextView = itemView.findViewById(R.id.tvMemId)

        fun updateUi(position: Int) {

            tvMemName.text = membershipPageResponse.get(position).iW_fMemberTypeName
            tvMemCat.text = membershipPageResponse.get(position).iW_fMembershipGroupName
            tvMemExpDate.text = membershipPageResponse.get(position).iW_fEndDate
            tvMemId.text = membershipPageResponse.get(position).iW_fMemberID
        }

    }
}