package com.incepteo.test.pageindicatorview.draw.data;

public enum RtlMode {On, Off, Auto}