package com.incepteo.test.webservices.response

import com.google.gson.annotations.SerializedName

data class MembershipRecordResponse(@SerializedName("IW_fCRN") val iW_fCRN : String,
                                    @SerializedName("IW_fEmailAddress") val iW_fEmailAddress : String,
                                    @SerializedName("IW_fFirstName") val iW_fFirstName : String,
                                    @SerializedName("IW_fLastName") val iW_fLastName : String,
                                    @SerializedName("IW_fPassword") val iW_fPassword : String,
                                    @SerializedName("IW_fPerson") val iW_fPerson : String,
                                    @SerializedName("IW_fPersonRecordID") val iW_fPersonRecordID : String,
                                    @SerializedName("IW_fUsername") val iW_fUsername : String,
                                    @SerializedName("R436059554") val r436059554 : List<Int>,
                                    @SerializedName("R436059906") val r436059906 : List<Int>,
                                    @SerializedName("createdAt") val createdAt : String,
                                    @SerializedName("createdBy") val createdBy : String,
                                    @SerializedName("createdBy") val id : String,
                                    @SerializedName("createdBy") val name : String,
                                    @SerializedName("createdBy") val objName : String,
                                    @SerializedName("createdBy") val tag : String,
                                    @SerializedName("createdBy") val updatedAt : String,
                                    @SerializedName("createdBy") val updatedBy : String)
