package com.incepteo.test

import android.app.Application
import com.incepteo.test.webservices.RestClient

class MainApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        restClient = RestClient()

    }

    companion object {

        private lateinit var restClient: RestClient

        fun getRestClient(): RestClient {
            return restClient
        }
    }

}