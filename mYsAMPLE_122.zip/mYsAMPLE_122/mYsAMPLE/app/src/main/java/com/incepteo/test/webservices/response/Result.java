package com.incepteo.test.webservices.response;

import com.google.gson.annotations.SerializedName;

public class Result<T> {

    /*"Status":true,
            "Message":"",
            "Errors":null*/

    @SerializedName("Count")
    private int listCount;

    @SerializedName("Message")
    private String message;

    @SerializedName("Status")
    private boolean status;

    @SerializedName("Result")
    private T resultResponse;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getListCount() {
        return listCount;
    }

    public void setListCount(int listCount) {
        this.listCount = listCount;
    }

    public T getResultResponse() {
        return resultResponse;
    }

    public void setResultResponse(T resultResponse) {
        this.resultResponse = resultResponse;
    }
}
