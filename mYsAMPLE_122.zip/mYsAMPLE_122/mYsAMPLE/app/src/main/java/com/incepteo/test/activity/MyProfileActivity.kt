package com.incepteo.test.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.Toolbar
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.incepteo.test.MainApplication
import com.incepteo.test.R
import com.incepteo.test.adapter.InvoicesAdapter
import com.incepteo.test.shared_preferences.Preferences
import com.incepteo.test.webservices.response.InvoicesResponse
import com.incepteo.test.webservices.response.ProfileScreenResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_my_profile.*
import kotlinx.android.synthetic.main.fragment_invoices.*
import retrofit2.Response

class MyProfileActivity : AppCompatActivity() {

    private val mCompositeDisposable = CompositeDisposable()

    private lateinit var preferences : Preferences

    private lateinit var tvUserName : TextView
    private lateinit var tvUserMail : TextView
    private lateinit var tvMobileNumber : TextView
    private lateinit var tvPhoneNumber : TextView
    private lateinit var tvLocation : TextView
    private lateinit var tvCustomerId : TextView
    private lateinit var ivCustomer : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_profile)

        preferences = Preferences()
        preferences.loadPreferences(this@MyProfileActivity)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        toolbar.title = "Profile Settings"
        setSupportActionBar(toolbar)

        if (supportActionBar != null) {
            supportActionBar!!.setHomeButtonEnabled(true)
            supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            //supportActionBar!!.title = ""
        }

        viewsInitialization()

        getProfileDetails()

    }

    private fun viewsInitialization() {

        tvUserName = findViewById(R.id.tvUserName)
        tvUserMail = findViewById(R.id.tvUserMail)
        tvMobileNumber = findViewById(R.id.tvMobileNumber)
        tvPhoneNumber = findViewById(R.id.tvPhoneNumber)
        tvLocation = findViewById(R.id.tvLocation)
        tvCustomerId = findViewById(R.id.tvCustomerId)
        ivCustomer = findViewById(R.id.ivCustomer)
    }

    private fun getProfileDetails() {

        /*
        * ["sessionId": "d278f45a604b4c568f9f8c08132e022e@436027609", "viewId": "O7bIn5HiSI-Wl-TUqiCqhQ", "id": "436057934", "objName": "IW_oPerson", "fieldList": "id,name,IW_fFullname,firstName,middleName,lastName,IW_fPrefix,IW_fHomeAddress,IW_fHomeCity,IW_fHomeStateProvince,IW_fHomePostCode,IW_fHomeCountry,IW_fGender,IW_fDateOfBirth,IW_fCRN,IW_fShirtSize,IW_fEmergencyContact1,IW_fEmergencyContact1Phone,IW_fEmergencyContact2,IW_fEmergencyContact2Phone,IW_fPreferredMailingAddress", "output": "json"]
        * */

            mCompositeDisposable.add(
            MainApplication.getRestClient().getApiServices().getProfileDetails(sessionId = preferences.sessionId,viewId = "O7bIn5HiSI-Wl-TUqiCqhQ",id = "436057934",objName = "IW_oPerson",fieldList = "id,name,IW_fFullname,firstName,middleName,lastName,IW_fPrefix,IW_fHomeAddress,IW_fHomeCity,IW_fHomeStateProvince,IW_fHomePostCode,IW_fHomeCountry,IW_fGender,IW_fDateOfBirth,IW_fCRN,IW_fShirtSize,IW_fEmergencyContact1,IW_fEmergencyContact1Phone,IW_fEmergencyContact2,IW_fEmergencyContact2Phone,IW_fPreferredMailingAddress,IW_fPhotographRawURL,",output = "json")
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(({ this.handleProfileDetailResults(it) }), ({ this.handleError() })))
    }

    private fun handleProfileDetailResults(response : Response<ProfileScreenResponse>){

        if (response.code()==200){

            setProfileDetails(response.body()!!)
        }else{

        }

    }

    private fun setProfileDetails(response: ProfileScreenResponse) {

        tvUserName.text = response.iW_fFullname
        tvMobileNumber.text = response.iW_fEmergencyContact1Phone
        tvPhoneNumber.text = response.iW_fEmergencyContact2Phone
        tvLocation.text = response.iW_fHomeAddress+response.iW_fHomeCity
        tvCustomerId.text = response.iW_fCRN

        Glide.with(this@MyProfileActivity).load(response.iW_fPhotographRawURL).circleCrop().into(ivCustomer)
    }

    private fun handleError(){

        Toast.makeText(this@MyProfileActivity,"Failure", Toast.LENGTH_SHORT).show()

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {
                finish()
                overridePendingTransition(R.anim.activity_back_in, R.anim.activity_back_out)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()

        mCompositeDisposable.clear()
    }
}
