package com.incepteo.test.fragment


import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import com.incepteo.test.MainApplication

import com.incepteo.test.R
import com.incepteo.test.activity.MainActivity
import com.incepteo.test.adapter.DashboardActivityAdapter
import com.incepteo.test.adapter.MembershipAdapter
import com.incepteo.test.shared_preferences.Preferences
import com.incepteo.test.webservices.response.LoginResponse
import com.incepteo.test.webservices.response.MembershipPageResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import retrofit2.Response

class MyMembershipsFragment : Fragment() {

    private lateinit var btnOverdue : Button
    private lateinit var btnActive : Button
    private lateinit var rvMemberShip : RecyclerView

    private lateinit var membershipAdapter: MembershipAdapter

    private val mCompositeDisposable = CompositeDisposable()

    private var memberShipId = "0"

    private lateinit var preferences : Preferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view : View = inflater.inflate(R.layout.fragment_my_memberships, container, false)

        viewsInitialization(view)

        preferences = Preferences()

        preferences.loadPreferences(context!!)

        btnOverdue.setOnClickListener {

            btnOverdue.background = ContextCompat.getDrawable(context!!,R.drawable.ripple_effect_primary)
            btnOverdue.setTextColor(ContextCompat.getColor(context!!,R.color.white))
            btnActive.background = ContextCompat.getDrawable(context!!,R.drawable.ripple_effect_secondary)
            btnActive.setTextColor(ContextCompat.getColor(context!!,R.color.colorPrimary))

        }

        btnActive.setOnClickListener {

            btnActive.background = ContextCompat.getDrawable(context!!,R.drawable.ripple_effect_primary)
            btnActive.setTextColor(ContextCompat.getColor(context!!,R.color.white))
            btnOverdue.background = ContextCompat.getDrawable(context!!,R.drawable.ripple_effect_secondary)
            btnOverdue.setTextColor(ContextCompat.getColor(context!!,R.color.colorPrimary))
        }

        getMembershipId()

        return view
    }

    private fun viewsInitialization(view: View) {

        btnActive = view.findViewById(R.id.btnActive)

        btnOverdue = view.findViewById(R.id.btnOverdue)
        rvMemberShip = view.findViewById(R.id.rvMemberShip)
        rvMemberShip.layoutManager = LinearLayoutManager(context)

    }

    private fun getMembershipId() {

        mCompositeDisposable.add(
            MainApplication.getRestClient().getApiServices().getMembershipId(sessionId = preferences.sessionId,startRow = "0",output = "json",query = "SELECT id FROM IW_oWebAuthentication WHERE IW_fUsername='alexandra36@demo.inwolk.com.au'",maxRows = "1")
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(({ this.handleMembershipIdResults(it) }), ({ this.handleError() })))
    }

    private fun handleMembershipIdResults(response : Response<List<List<Int>>>){

        if (response.code()==200){

            memberShipId = response.body()!!.get(0).get(0).toString()
            getMemberShipPage()

        }else{

        }

    }

    private fun getMemberShipPage() {

        mCompositeDisposable.add(
            MainApplication.getRestClient().getApiServices().getMembershipPage(objNames = "IW_oMembership,IW_oMembershipGroup,IW_oMemberType",composite = "0",fieldList = "id,IW_fMemberTypeName,IW_fMemberID,IW_fEndDate,IW_fMembershipGroupName,IW_fMemberName,IW_fActivateOnlineRenewal,IW_fMembershipProductCode,IW_fOrganisation",output = "json",filterValue = "436057934",filterName = "IW_fRecipientPerson",
                                                                               viewId = "6ULv32FUSSetqeF0ltxxVg",startRow = "0",rowsperpage = "50",sessionId = preferences.sessionId)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(({ this.handleMembershipPageResults(it) }), ({ this.handleError() })))

    }

    private fun handleMembershipPageResults(response : Response<List<MembershipPageResponse>>){

        if (response.code()==200){

            membershipAdapter = MembershipAdapter(response.body()!!)
            rvMemberShip.adapter = membershipAdapter

        }else{

        }

    }

    private fun handleError(){

        Toast.makeText(context,"Failure", Toast.LENGTH_SHORT).show()

    }

    override fun onDestroy() {
        super.onDestroy()

        mCompositeDisposable.clear()
    }
}
