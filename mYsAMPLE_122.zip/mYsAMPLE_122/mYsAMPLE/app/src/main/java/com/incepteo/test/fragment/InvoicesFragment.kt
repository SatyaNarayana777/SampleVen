package com.incepteo.test.fragment


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import com.incepteo.test.MainApplication

import com.incepteo.test.R
import com.incepteo.test.adapter.InvoicesAdapter
import com.incepteo.test.adapter.MembershipAdapter
import com.incepteo.test.shared_preferences.Preferences
import com.incepteo.test.webservices.response.InvoicesResponse
import com.incepteo.test.webservices.response.MembershipPageResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_my_memberships.*
import retrofit2.Response

class InvoicesFragment : Fragment() {

    private lateinit var btnOutstanding : Button
    private lateinit var btnPaid : Button

    private val mCompositeDisposable = CompositeDisposable()

    private lateinit var rvInvoices : RecyclerView
    private lateinit var llOutStandingInvoices : LinearLayout
    private lateinit var llInvoicesDate : LinearLayout

    private lateinit var invoicesAdapter: InvoicesAdapter

    private lateinit var preferences : Preferences

    private var outStandingInvoicesList : MutableList<InvoicesResponse> = mutableListOf()

    private var paidInvoicesList : MutableList<InvoicesResponse> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view : View = inflater.inflate(R.layout.fragment_invoices, container, false)

        preferences = Preferences()
        preferences.loadPreferences(context!!)

        viewsInitialization(view)

        btnOutstanding.setOnClickListener {

            btnOutstanding.background = ContextCompat.getDrawable(context!!,R.drawable.ripple_effect_primary)
            btnOutstanding.setTextColor(ContextCompat.getColor(context!!,R.color.white))
            btnPaid.background = ContextCompat.getDrawable(context!!,R.drawable.ripple_effect_secondary)
            btnPaid.setTextColor(ContextCompat.getColor(context!!,R.color.colorPrimary))
            llOutStandingInvoices.visibility = View.VISIBLE
            llInvoicesDate.visibility = View.VISIBLE

            invoicesAdapter = InvoicesAdapter(outStandingInvoicesList)
            rvInvoices.adapter = invoicesAdapter
        }

        btnPaid.setOnClickListener {

            btnPaid.background = ContextCompat.getDrawable(context!!,R.drawable.ripple_effect_primary)
            btnPaid.setTextColor(ContextCompat.getColor(context!!,R.color.white))
            btnOutstanding.background = ContextCompat.getDrawable(context!!,R.drawable.ripple_effect_secondary)
            btnOutstanding.setTextColor(ContextCompat.getColor(context!!,R.color.colorPrimary))
            llOutStandingInvoices.visibility = View.GONE
            llInvoicesDate.visibility = View.GONE

            invoicesAdapter = InvoicesAdapter(paidInvoicesList)
            rvInvoices.adapter = invoicesAdapter
        }

        getInvoicesList()

        return view
    }

    private fun viewsInitialization(view: View) {

        btnOutstanding = view.findViewById(R.id.btnOutstanding)
        btnPaid = view.findViewById(R.id.btnPaid)
        rvInvoices = view.findViewById(R.id.rvInvoices)
        llInvoicesDate = view.findViewById(R.id.llInvoicesDate)
        llOutStandingInvoices = view.findViewById(R.id.llOutStandingInvoices)
        rvInvoices.layoutManager = LinearLayoutManager(context)
    }

    private fun getInvoicesList() {

        /*
        *     *["sessionId": "c5ef939cb41d4726aa4f632a0fe7a971@436027609", "filterName": "IW_fBillToPerson", "startRow": "0", "rowsperpage": "50", "filterValue": "436057935", "viewId": "665x6vNDQNmX4mdTcT6CGg", "composite": "0", "output": "json", "fieldList": "id,name,IW_fBillToPerson,IW_fDateConfirmed,IW_fItemTotal,IW_fTotalTax,IW_fOrderTotal,IW_fOrderBalance,IW_fOrderTemplateURL,IW_fDescription,IW_fOrderStatusBaseType,IW_fOrderBalance"]

        * */

        mCompositeDisposable.add(
            MainApplication.getRestClient().getApiServices().getInvoiceDetails(sessionId = preferences.sessionId,filterName = "IW_fBillToPerson",startRow = "0",rowsperpage = "50",filterValue = "436057935",viewId = "665x6vNDQNmX4mdTcT6CGg",composite = "0",output = "json",fieldList = "id,name,IW_fBillToPerson,IW_fDateConfirmed,IW_fItemTotal,IW_fTotalTax,IW_fOrderTotal,IW_fOrderBalance,IW_fOrderTemplateURL,IW_fDescription,IW_fOrderStatusBaseType,IW_fOrderBalance")
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(({ this.handleInvoiceResults(it) }), ({ this.handleError() })))
    }

    private fun handleInvoiceResults(response : Response<List<InvoicesResponse>>){

        if (response.code()==200){

            for(i in response.body()!!)

            if (i.iW_fOrderStatusBaseType=="confirmed"&&i.iW_fOrderBalance.toFloat()>0F) {

                outStandingInvoicesList.add(i)
            }else if(i.iW_fOrderStatusBaseType=="confirmed"&&i.iW_fOrderBalance.toFloat()==0F){
                paidInvoicesList.add(i)
            }

            invoicesAdapter = InvoicesAdapter(paidInvoicesList)
            rvInvoices.adapter = invoicesAdapter

        }else{

        }

    }

    private fun handleError(){

        Toast.makeText(context,"Failure", Toast.LENGTH_SHORT).show()

    }

    override fun onDestroy() {
        super.onDestroy()
        mCompositeDisposable.clear()
    }
}
