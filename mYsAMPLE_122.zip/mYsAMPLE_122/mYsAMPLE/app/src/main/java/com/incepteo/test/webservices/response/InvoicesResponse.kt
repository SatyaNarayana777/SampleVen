package com.incepteo.test.webservices.response

import com.google.gson.annotations.SerializedName

/*
* "IW_fBillToPerson" = 436057935;
    "IW_fDateConfirmed" = "2019-06-16";
    "IW_fDescription" = "Rally Junior Navigator Membership - 12 Months";
    "IW_fItemTotal" = "245.45";
    "IW_fOrderBalance" = 160;
    "IW_fOrderStatusBaseType" = confirmed;
    "IW_fOrderTemplateURL" = "https://cloud.octozy.com/prod1/servlet/Template?hint=file&objDefId=436031146&templateId=436033520&id=436059260";
    "IW_fOrderTotal" = 270;
    "IW_fTotalTax" = "24.55";
    id = 436059260;
        name = 2;
    objName = "IW_oOrder";
*
* */

data class InvoicesResponse(@SerializedName("IW_fBillToPerson")val iW_fBillToPerson : String,
                            @SerializedName("IW_fDateConfirmed")val iW_fDateConfirmed : String,
                            @SerializedName("IW_fDescription")val iW_fDescription : String,
                            @SerializedName("IW_fItemTotal")val iW_fItemTotal : String,
                            @SerializedName("IW_fOrderBalance")val iW_fOrderBalance : String,
                            @SerializedName("IW_fOrderStatusBaseType")val iW_fOrderStatusBaseType : String,
                            @SerializedName("IW_fOrderTemplateURL")val iW_fOrderTemplateURL : String,
                            @SerializedName("IW_fOrderTotal")val iW_fOrderTotal : String,
                            @SerializedName("IW_fTotalTax")val iW_fTotalTax : String,
                            @SerializedName("id")val id : String,
                            @SerializedName("name")val name : String,
                            @SerializedName("objName")val objName : String)