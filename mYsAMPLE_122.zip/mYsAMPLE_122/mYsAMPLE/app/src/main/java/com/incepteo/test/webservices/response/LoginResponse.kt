package com.incepteo.test.webservices.response

import com.google.gson.annotations.SerializedName

/*
* {
    sessionId = "2baf1cd70806421db957fc9c7f5aa966@436027609";
    status = ok;
}
* */

data class LoginResponse(@SerializedName("sessionId")val sessionId : String,
                         @SerializedName("status")val status : String)