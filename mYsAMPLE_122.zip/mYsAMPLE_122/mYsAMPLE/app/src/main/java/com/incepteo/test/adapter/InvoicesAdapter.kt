package com.incepteo.test.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.incepteo.test.R
import com.incepteo.test.model.DashboardActivityModel
import com.incepteo.test.webservices.response.InvoicesResponse

class InvoicesAdapter constructor(private val invoicesList : List<InvoicesResponse>) : RecyclerView.Adapter<InvoicesAdapter.ViewHolder>() {

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val view: View = LayoutInflater.from(p0.context).inflate(R.layout.row_item_invoices, p0, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return invoicesList.size
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        p0.updateUi(p1)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val tvInvRef : TextView = itemView.findViewById(R.id.tvInvRef)
        val tvInvDate : TextView = itemView.findViewById(R.id.tvInvDate)
        val tvInvTotal : TextView = itemView.findViewById(R.id.tvInvTotal)
        val tvInvBalance : TextView = itemView.findViewById(R.id.tvInvBalance)
        val tvInvDesc : TextView = itemView.findViewById(R.id.tvInvDesc)

        fun updateUi(position: Int) {

            tvInvRef.text = invoicesList[position].objName
            tvInvDate.text = invoicesList[position].iW_fDateConfirmed
            tvInvTotal.text = invoicesList[position].iW_fOrderTotal
            tvInvBalance.text = invoicesList[position].iW_fOrderBalance
            tvInvDesc.text = invoicesList[position].iW_fDescription
        }

    }
}