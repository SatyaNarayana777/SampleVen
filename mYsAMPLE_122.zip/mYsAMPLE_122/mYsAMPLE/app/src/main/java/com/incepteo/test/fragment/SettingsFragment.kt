package com.incepteo.test.fragment


import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.bumptech.glide.Glide.init

import com.incepteo.test.R
import com.incepteo.test.activity.MyProfileActivity

class SettingsFragment : Fragment() {

    private val listTextItem =
        arrayOf("Profile Settings")

    private val listImageItem = intArrayOf(

        R.drawable.ic_settings
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view : View = inflater.inflate(R.layout.fragment_settings, container, false)

        val lvSettings : ListView = view.findViewById(R.id.lvSettings)

        val listAdapter = SettingsListAdapter(context!!, listTextItem, listImageItem)
        lvSettings.adapter = listAdapter

        lvSettings.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            when (position) {

                0 -> {

                    val intent = Intent(activity, MyProfileActivity::class.java)
                    startActivity(intent)
                }

            }
        }

        return view
    }

    /*Inner class adapter for Settings*/
    private inner class SettingsListAdapter internal constructor(
        context: Context,
        private val settingsTextList: Array<String>,
        private val imagesList: IntArray
    ) :
        BaseAdapter() {

        private var inflater: LayoutInflater? = null

        init {

            inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

        }

        override fun getCount(): Int {
            return settingsTextList.size
        }

        override fun getItem(position: Int): Any {

            return position
        }

        override fun getItemId(position: Int): Long {

            return position.toLong()
        }

        @SuppressLint("ViewHolder")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

            val holder = ViewHolder()
            val rowView:  View = inflater!!.inflate(R.layout.settings_list_item, null)

            holder.ivMoreItem = rowView.findViewById(R.id.ivSettingItem)
            holder.tvMoreItem = rowView.findViewById(R.id.tvSettingItem)

            holder.ivMoreItem.setImageResource(imagesList[position])
            holder.tvMoreItem.text = settingsTextList[position]

            return rowView
        }

        internal inner class ViewHolder {

            lateinit var ivMoreItem: ImageView
            lateinit var tvMoreItem: TextView

        }
    }


}
