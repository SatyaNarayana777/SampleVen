package com.incepteo.test.webservices

import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class RestClient{
    // FCM push notification server URL

        private val BASE_URL = " https://cloud.octozy.com/rest/api/" // Working

        private lateinit var apiInterface: ApiInterface

       init{

            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(buildOkHttpClient())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build()

            apiInterface = retrofit.create(ApiInterface::class.java)

        }

        public fun getApiServices(): ApiInterface {
            return apiInterface
        }

        // build OkHttp client
        private fun buildOkHttpClient(): OkHttpClient {

            val logging = HttpLoggingInterceptor()
            // set your desired log level
            logging.level = HttpLoggingInterceptor.Level.BODY

            //retry on connection failure
            val httpClient = OkHttpClient.Builder()
                .writeTimeout(120, TimeUnit.SECONDS)
                .connectTimeout(120, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .readTimeout(120, TimeUnit.SECONDS)
                .connectionPool(ConnectionPool(0, 1, TimeUnit.NANOSECONDS))

            httpClient.addInterceptor { chain ->
                val original = chain.request()

                val request = original.newBuilder()
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header("Accept-Language", "en-gb")
                    .method(original.method(), original.body())
                    //.header("Authorization", getCustomAuth())
                    .build()
                return@addInterceptor chain.proceed(request)
            }

            httpClient.addInterceptor(logging)
            httpClient.connectTimeout(1, TimeUnit.MINUTES)
            httpClient.readTimeout(1, TimeUnit.MINUTES)

            return httpClient.build()
        }

        // FCM Ahentication
        private fun getFCMCustomAuth(): String {

            return "Key=" + "AAAA1ad-Hvs:APA91bHD35djyGUOZAZqUstLi3ZyWYWXckuEXqjMF3BQv5EyQtotJBSFMpIOBUQZpYlczqZ3wCp5lb7wiAD1vpOgaX--UyZQHEqvhArSCQ5GrRrn6uU31PZ_sRPIVZNjWjfoRTPHTPW7"

        }
}