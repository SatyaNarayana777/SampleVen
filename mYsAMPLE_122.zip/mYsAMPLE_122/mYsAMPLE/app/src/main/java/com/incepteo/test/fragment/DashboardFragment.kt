package com.incepteo.test.fragment


import android.os.Bundle
import android.os.Handler
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.view.ViewPager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.incepteo.test.MainApplication
import com.incepteo.test.R
import com.incepteo.test.adapter.DashboardActivityAdapter
import com.incepteo.test.model.DashboardActivityModel
import com.incepteo.test.pageindicatorview.PageIndicatorView
import com.incepteo.test.pageindicatorview.ViewPagerDetailFragment
import com.incepteo.test.shared_preferences.Preferences
import com.incepteo.test.webservices.response.DashboardActiviyResponse
import com.incepteo.test.webservices.response.ProfileScreenResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

class DashboardFragment : Fragment() {

    private lateinit var preferences : Preferences

    private lateinit var vpSlides : ViewPager
    private lateinit var pageIndicatorView : PageIndicatorView
    private lateinit var rvDashboardActivity : RecyclerView
    private lateinit var dashboardActivityAdapter: DashboardActivityAdapter
    private var customSlideFragmentsList: MutableList<Fragment> = ArrayList()
    private val DELAYMS: Long = 500
    private val PERIODMS: Long = 2000
    private var currentPage: Int = 0
    private var dashboardActivityList:MutableList<DashboardActivityModel> = ArrayList()

    private val mCompositeDisposable = CompositeDisposable()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view : View = inflater.inflate(R.layout.fragment_dashboard, container, false)

        setHasOptionsMenu(false)

        preferences = Preferences()
        preferences.loadPreferences(context!!)

        viewsInitialization(view)

        setUpViewPager()

        getDashboardActivityResponse()

        return view
    }

    private fun getDashboardActivityResponse() {

            mCompositeDisposable.add(
                MainApplication.getRestClient().getApiServices().getDashboardList(sessionId = preferences.sessionId,viewId = "6w7vhX5MTwix_ExzsaTBsw",fieldList = "id,IW_fTitle,IW_fMessage,IW_fStartDate,IW_fNotificationURL",output = "json")
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .subscribe(({ this.handleDashboardActivityResults(it) }), ({ this.handleError() })))

    }

    private fun handleDashboardActivityResults(response : Response<List<DashboardActiviyResponse>>){

        if (response.code()==200){

            setUpActivityList(response.body()!!)
        }else{

        }

    }

    private fun setUpActivityList(list: List<DashboardActiviyResponse>) {

        dashboardActivityAdapter = DashboardActivityAdapter(list)
        rvDashboardActivity.adapter = dashboardActivityAdapter
    }

    private fun handleError(){

        Toast.makeText(context,"Failure", Toast.LENGTH_SHORT).show()

    }

    private fun setUpViewPager() {

        customSlideFragmentsList.add(ViewPagerDetailFragment.newInstance())
        customSlideFragmentsList.add(ViewPagerDetailFragment.newInstance())
        customSlideFragmentsList.add(ViewPagerDetailFragment.newInstance())
        customSlideFragmentsList.add(ViewPagerDetailFragment.newInstance())
        customSlideFragmentsList.add(ViewPagerDetailFragment.newInstance())
        customSlideFragmentsList.add(ViewPagerDetailFragment.newInstance())
        customSlideFragmentsList.add(ViewPagerDetailFragment.newInstance())

        val slidesAdapter = SlidesAdapter(fragmentManager!!, 7, customSlideFragmentsList)
        vpSlides.adapter = slidesAdapter
        pageIndicatorView.setViewPager(vpSlides)

        /*val handler = Handler()

        val update = Runnable {
            if (currentPage == 8 - 1) {
                currentPage = 0
            }
            vpSlides.setCurrentItem(currentPage++, true)
        }
        vpSlides.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {
            }

            override fun onPageSelected(position: Int) {
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                currentPage = position
            }
        })

        Timer().schedule(object : TimerTask() {
            override fun run() {
                handler.post(update)
            }

        }, DELAYMS, PERIODMS)*/
    }

    private fun viewsInitialization(view: View) {

        vpSlides = view.findViewById(R.id.vpSlides)
        pageIndicatorView = view.findViewById(R.id.pageIndicatorView)
        rvDashboardActivity = view.findViewById(R.id.rvDashboardActivity)
        rvDashboardActivity.layoutManager = LinearLayoutManager(context)
    }

    inner class SlidesAdapter(fm: FragmentManager, count: Int, customSLideFragmentList: MutableList<Fragment>) : FragmentStatePagerAdapter(fm) {

        private var count: Int = 0
        private var customSlideFragmentList: MutableList<Fragment>

        init {
            this.count = count
            this.customSlideFragmentList = customSLideFragmentList
        }

        override fun getItem(position: Int): Fragment {
            return customSlideFragmentList[position]
        }

        override fun getCount(): Int {
            return count
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        mCompositeDisposable.clear()
    }
}
