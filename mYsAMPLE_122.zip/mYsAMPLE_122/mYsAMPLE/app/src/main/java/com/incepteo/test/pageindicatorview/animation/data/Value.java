package com.incepteo.test.pageindicatorview.animation.data;

public interface Value {/*empty*/}
