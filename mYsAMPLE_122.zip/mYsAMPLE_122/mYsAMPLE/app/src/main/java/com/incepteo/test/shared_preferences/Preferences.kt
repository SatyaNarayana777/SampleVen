package com.incepteo.test.shared_preferences

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager

class Preferences {

    var isUserLogin: Boolean = false

    var sessionId: String = ""

    fun savePreferences(context: Context) {

        val editor: SharedPreferences.Editor
        val pref = PreferenceManager.getDefaultSharedPreferences(context)
        editor = pref.edit()

        editor.putBoolean("IS_USER_LOGIN", isUserLogin)
        editor.putString("SESSION_ID", sessionId)

        editor.apply()
    }

    fun loadPreferences(context: Context) {

        val pref = PreferenceManager.getDefaultSharedPreferences(context)

        isUserLogin = pref.getBoolean("IS_USER_LOGIN", false)
        sessionId = pref.getString("SESSION_ID", "")!!

    }

    fun clearPreferences(context: Context) {

        val editor: SharedPreferences.Editor
        val pref = PreferenceManager.getDefaultSharedPreferences(context)
        editor = pref.edit()
        editor.clear()
        editor.apply()
    }
}
