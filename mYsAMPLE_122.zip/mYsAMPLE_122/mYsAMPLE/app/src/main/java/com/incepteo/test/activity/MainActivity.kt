package com.incepteo.test.activity

import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.WindowManager
import android.widget.TextView
import com.incepteo.test.R
import com.incepteo.test.fragment.*

class MainActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        toolbar.title = "Dashboard"
        setSupportActionBar(toolbar)

        /*if (supportActionBar != null) {
            supportActionBar!!.setHomeButtonEnabled(true)
            supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            supportActionBar!!.title = ""
        }*/

        val navView: BottomNavigationView = findViewById(R.id.nav_view)

        navView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)

        navView.selectedItemId = R.id.navigation_dashboard
    }

    private val onNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->

        when (item.itemId) {

            R.id.navigation_dashboard -> {

                toolbar.title = "Dashboard"

                navigateToFragment(DashboardFragment())

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_invoices -> {

                toolbar.title = "Invoices"

                navigateToFragment(InvoicesFragment())

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_memberships -> {

                toolbar.title = "My Memberships"

                navigateToFragment(MyMembershipsFragment())

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_events -> {

                toolbar.title = "Events"

                navigateToFragment(EventsFragment())

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_settings -> {

                toolbar.title = "Settings"

                navigateToFragment(SettingsFragment())

                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    private fun navigateToFragment(fragment : Fragment){

        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.frameLayout, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

}
