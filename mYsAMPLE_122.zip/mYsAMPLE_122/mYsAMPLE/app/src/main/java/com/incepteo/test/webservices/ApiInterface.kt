package com.incepteo.test.webservices

import android.os.Process
import com.incepteo.test.webservices.response.*
import io.reactivex.Single
import retrofit2.Response
import retrofit2.http.*

interface ApiInterface {

    @GET("login")
    abstract fun loginWithDetails(@Query("loginName") userName: String, @Query("password") password: String, @Query("output") output: String ): Single<Response<LoginResponse>>

    @GET("selectQuery")
    abstract fun getMembershipId(@Query("sessionId") sessionId: String, @Query("startRow") startRow: String, @Query("maxRows") maxRows: String ,@Query("output") output: String,@Query("query") query: String ): Single<Response<List<List<Int>>>>

    @GET("getRecord")
    abstract fun getMembershipRecord(@Query("sessionId") sessionId: String, @Query("objNames") objNames: String,@Query("output") output: String,@Query("id") id: String ): Single<Response<MembershipRecordResponse>>

    @GET("getPage")
    abstract fun getMembershipPage(@Query("objNames") objNames: String, @Query("composite") composite: String,@Query("fieldList") fieldList: String,@Query("output") output: String,@Query("filterValue") filterValue: String,@Query("filterName") filterName: String,@Query("viewId") viewId: String,@Query("startRow") startRow: String,@Query("rowsperpage") rowsperpage: String,@Query("sessionId") sessionId: String ): Single<Response<List<MembershipPageResponse>>>

    @GET("getPage")
    abstract fun getInvoiceDetails(@Query("sessionId") sessionId: String, @Query("filterName") filterName: String,@Query("startRow") startRow: String,@Query("rowsperpage") rowsperpage: String,@Query("filterValue") filterValue: String,@Query("viewId") viewId: String,@Query("composite") composite: String,@Query("output") output: String,@Query("fieldList") fieldList: String ): Single<Response<List<InvoicesResponse>>>

    @GET("getRecord")
    abstract fun getProfileDetails(@Query("sessionId") sessionId: String, @Query("viewId") viewId: String,@Query("id") id: String,@Query("objName") objName: String,@Query("fieldList") fieldList: String,@Query("output") output: String): Single<Response<ProfileScreenResponse>>

    @GET("getPage")
    abstract fun getDashboardList(@Query("viewId") viewId: String, @Query("sessionId") sessionId: String, @Query("output") output: String, @Query("Field List") fieldList: String) : Single<Response<List<DashboardActiviyResponse>>>

    /*
    * ["viewId": "6w7vhX5MTwix_ExzsaTBsw", "sessionId": "d8fd0668164f4d8dad3e25cf86566f17@436027609", "output": "json", "Field List": "id,IW_fTitle,IW_fMessage,IW_fStartDate,IW_fNotificationURL"]
    * */
}