package com.incepteo.test.webservices.response

import com.google.gson.annotations.SerializedName

/*
*   "IW_fDisplayDate" = "2019-08-11";
    "IW_fEndDate" = "2019-09-29T14:00:00Z";
    "IW_fMessage" = "Message content for the global demo notification";
    "IW_fScope" = Global;
    "IW_fStartDate" = "2019-08-11T14:00:00Z";
    "IW_fTitle" = "This is a global demo notification";
    "IW_fType" = ALL;
    createdAt = "2019-08-13T11:37:03Z";
    createdBy = "Octozy Super Admin User";
    id = 436335653;
    name = "Global - Demo Notification";
    objName = "IW_oNotification";
    updatedAt = "2019-08-19T05:56:51Z";
    updatedBy = "Octozy Super Admin User";
* */

data class DashboardActiviyResponse(@SerializedName("IW_fDisplayDate")val iW_fDisplayDate : String,
                                    @SerializedName("IW_fEndDate")val iW_fEndDate : String,
                                    @SerializedName("IW_fMessage")val iW_fMessage : String,
                                    @SerializedName("IW_fScope")val iW_fScope : String,
                                    @SerializedName("IW_fStartDate")val iW_fStartDate : String,
                                    @SerializedName("IW_fTitle")val iW_fTitle : String,
                                    @SerializedName("IW_fType")val iW_fType : String,
                                    @SerializedName("createdAt")val createdAt : String,
                                    @SerializedName("createdBy")val createdBy : String,
                                    @SerializedName("id")val id : String,
                                    @SerializedName("name")val name : String,
                                    @SerializedName("objName")val objName : String,
                                    @SerializedName("updatedAt")val updatedAt : String,
                                    @SerializedName("updatedBy")val updatedBy : String)