package com.incepteo.test.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import com.incepteo.test.MainApplication
import com.incepteo.test.R
import com.incepteo.test.helpers.InternetConnection
import com.incepteo.test.shared_preferences.Preferences
import com.incepteo.test.webservices.response.LoginResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import retrofit2.Response
import java.lang.Exception
import java.util.regex.Pattern


class LoginActivity : AppCompatActivity() {

    private lateinit var btnSignIn : TextView
    private lateinit var etEmail : EditText
    private lateinit var etPassword : EditText
    private lateinit var ivLogin : ImageView
    private lateinit var pBar : ProgressBar
    private val mCompositeDisposable = CompositeDisposable()

    private lateinit var preferences : Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        viewsInitialization()

        preferences = Preferences()

        btnSignIn.setOnClickListener {

            if (InternetConnection.isNetworkAvailable(this@LoginActivity)){

                getUserLogin()

            }else{

            }
        }

        ivLogin.setOnClickListener {

            btnSignIn.performClick()
        }
    }

    private fun getUserLogin() {

        if(etEmail.text.toString().trim().isEmpty()){

        }else if(etPassword.text.toString().trim().isEmpty()){

        }else{

            val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
            val pattern = Pattern.compile(emailPattern)

            if (pattern.matcher(etEmail.text.toString().trim()).matches()){

                btnSignIn.visibility = View.GONE
                ivLogin.visibility = View.GONE
                pBar.visibility = View.VISIBLE

                mCompositeDisposable.add(
                    MainApplication.getRestClient().getApiServices().loginWithDetails(etEmail.text.toString().trim(),etPassword.text.toString().trim(),"json")
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.io())
                        .subscribe(({ this.handleLoginResults(it) }), ({ this.handleError() })))
               /* val intent = Intent(this@LoginActivity, MainActivity::class.java)
                startActivity(intent)
                finish()*/
            }else{

                btnSignIn.visibility = View.VISIBLE
                ivLogin.visibility = View.VISIBLE
                pBar.visibility = View.GONE
            }
        }

    }

    private fun handleLoginResults(response : Response<LoginResponse>){

        if (response.code()==200){

            if(response.body()!!.status=="ok"){

                preferences.sessionId = response.body()!!.sessionId

                preferences.savePreferences(this@LoginActivity)

                val intent = Intent(this@LoginActivity, MainActivity::class.java)
                startActivity(intent)
                finish()

            }else{

                btnSignIn.visibility = View.VISIBLE
                ivLogin.visibility = View.VISIBLE
                pBar.visibility = View.GONE
            }

        }else{

            btnSignIn.visibility = View.VISIBLE
            ivLogin.visibility = View.VISIBLE
            pBar.visibility = View.GONE
        }

    }

    private fun handleError(){

        btnSignIn.visibility = View.GONE
        ivLogin.visibility = View.GONE
        pBar.visibility = View.VISIBLE

        Toast.makeText(this@LoginActivity,"Failure",Toast.LENGTH_SHORT).show()

    }

    private fun viewsInitialization() {

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnSignIn = findViewById(R.id.btnSignIn)
        ivLogin = findViewById(R.id.ivLogin)
        pBar = findViewById(R.id.pBar)
    }

    override fun onDestroy() {
        super.onDestroy()

        mCompositeDisposable.clear()
    }
}
