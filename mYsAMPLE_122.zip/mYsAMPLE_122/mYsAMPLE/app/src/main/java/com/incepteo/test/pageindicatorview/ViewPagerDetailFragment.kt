package com.incepteo.test.pageindicatorview


import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.incepteo.test.R

class ViewPagerDetailFragment : Fragment() {

    companion object {
        fun newInstance(/*tourSlidesData: TourSlidesData*/): Fragment {
            val bundle = Bundle()
            //bundle.putParcelable("tourSlidesData", tourSlidesData)
            val customSlideFragment = ViewPagerDetailFragment()
            customSlideFragment.arguments = bundle
            return customSlideFragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view : View = inflater.inflate(R.layout.fragment_view_pager_detail, container, false)

        viewsInitialization(view)

        /*if (arguments != null) {
            tourSlidesData = arguments.getParcelable("tourSlidesData")
        }*/

        return view
    }

    private fun viewsInitialization(view: View) {

    }


}
