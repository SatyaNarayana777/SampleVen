package com.incepteo.test.pageindicatorview.draw.data;

public enum Orientation {HORIZONTAL, VERTICAL}
