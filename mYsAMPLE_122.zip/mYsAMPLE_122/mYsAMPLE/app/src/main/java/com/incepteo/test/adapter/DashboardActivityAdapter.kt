package com.incepteo.test.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.incepteo.test.R
import com.incepteo.test.webservices.response.DashboardActiviyResponse

class DashboardActivityAdapter constructor(private val dashboardActivityList : List<DashboardActiviyResponse>) : RecyclerView.Adapter<DashboardActivityAdapter.ViewHolder>() {

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val view: View = LayoutInflater.from(p0.context).inflate(R.layout.row_item_dashboard, p0, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return dashboardActivityList.size
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        p0.updateUi(p1)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val tvDateDay : TextView = itemView.findViewById(R.id.tvDateDay)
        private val tvDateMonth : TextView = itemView.findViewById(R.id.tvDateMonth)
        private val tvDashActTitle : TextView = itemView.findViewById(R.id.tvDashActTitle)
        private val tvDashActMessage : TextView = itemView.findViewById(R.id.tvDashActMessage)

        fun updateUi(position: Int) {
            //2019-08-11
            val date = dashboardActivityList[position].iW_fDisplayDate

            val splitValues = date.split("-")

            val monthName = getMonthName(splitValues[1])

            tvDateDay.text = splitValues[2]
            tvDateMonth.text = monthName

            tvDashActTitle.text = dashboardActivityList[position].iW_fTitle
            tvDashActMessage.text = dashboardActivityList[position].iW_fMessage
        }

    }

    private fun getMonthName(monthValue: String): String {

        return when (monthValue) {
            "1" -> {
                "Jan"
            }
            "2" -> {
                "Feb"
            }
            "3" -> {
                "Mar"
            }
            "4" -> {
                "Apr"
            }
            "5" -> {
                "May"
            }
            "6" -> {
                "Jun"
            }
            "7" -> {
                "Jul"
            }
            "8" -> {
                "Aug"
            }
            "9" -> {
                "Sep"
            }
            "10" -> {
                "Oct"
            }
            "11" -> {
                "Nov"
            }
            "12" -> {
                "Dec"
            }
            else -> {
                "Jan"
            }
        }

    }
}