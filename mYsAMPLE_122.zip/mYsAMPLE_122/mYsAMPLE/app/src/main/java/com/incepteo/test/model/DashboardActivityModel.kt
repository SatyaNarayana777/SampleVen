package com.incepteo.test.model

data class DashboardActivityModel(private val sam : String)